package com.lhester.polendey.trikila;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class logincustomer extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private String emm="";
    private String pas="";
    private ProgressDialog loadingbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logincustomer);
        mAuth=FirebaseAuth.getInstance();
        Button btnlogin=findViewById(R.id.btnlogin);
        Button btncancel=findViewById(R.id.btncancel);
        final EditText em=findViewById(R.id.txtemail);
        final EditText ps=findViewById(R.id.txtpassword);
        loadingbar=new ProgressDialog(this);
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
                finish();

            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                emm = em.getText().toString();
                pas = ps.getText().toString();
                if (emm == "") {
                    Toast.makeText(logincustomer.this, "Check Email ", Toast.LENGTH_SHORT).show();
                }
                if (pas == "") {
                    Toast.makeText(logincustomer.this, "Check Password ", Toast.LENGTH_SHORT).show();
                } else {
                    loadingbar.setTitle("Customer Login");
                    loadingbar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    loadingbar.setIndeterminate(true);
                    loadingbar.setCancelable(false);
                    loadingbar.setMessage("Please Wait..");
                    loadingbar.show();
                    mAuth.signInWithEmailAndPassword(emm, pas)
                            .addOnCompleteListener(logincustomer.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        Toast.makeText(logincustomer.this, "Log in Error", Toast.LENGTH_SHORT).show();
                                        loadingbar.dismiss();
                                        return;
                                    } else {
                                        Intent intent = new Intent(logincustomer.this,CustomerMapActivity.class);
                                        startActivity(intent);
                                        Toast.makeText(logincustomer.this, "Log in Successful", Toast.LENGTH_SHORT).show();
                                        loadingbar.dismiss();
                                        finish();
                                        return;
                                    }
                                }
                            });
                }
            }
        });
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
                return;
            }
        });
    }
    public void Register_Customer(View v){
        Intent intent = new Intent(logincustomer.this,register_customer.class);
        startActivity(intent);
        finish();
        return;
    }
}
