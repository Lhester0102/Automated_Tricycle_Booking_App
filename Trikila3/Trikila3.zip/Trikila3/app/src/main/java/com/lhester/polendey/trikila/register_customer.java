package com.lhester.polendey.trikila;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register_customer extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private DatabaseReference CustomerDatabaseRef;

    private String em="";
    private String pas="";
    private  String CustomerOnlineID;
    private ProgressDialog loadingbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer);
        mAuth = FirebaseAuth.getInstance();




        Button btnreg=findViewById(R.id.btnregister);
        Button btncancel=findViewById(R.id.btncancel);
        final EditText txtemail=findViewById(R.id.txtemail);
        final EditText txtpas=findViewById(R.id.txtpassword);
        loadingbar = new ProgressDialog(this);
        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                em = txtemail.getText().toString();
                pas = txtpas.getText().toString();
                if (em== "") {
                    Toast.makeText(register_customer.this, "Check Email ", Toast.LENGTH_SHORT).show();
                }
                if (pas == "") {
                    Toast.makeText(register_customer.this, "Check Password ", Toast.LENGTH_SHORT).show();
                } else {
                    loadingbar.setTitle("Customer Registration");
                    loadingbar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    loadingbar.setIndeterminate(true);
                    loadingbar.setCancelable(false);
                    loadingbar.setMessage("Please Wait..");
                    loadingbar.show();
                    mAuth.createUserWithEmailAndPassword(em, pas)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        CustomerOnlineID=mAuth.getCurrentUser().getUid();
                                        CustomerDatabaseRef= FirebaseDatabase.getInstance().getReference()
                                                .child("Users").child("Customers").child(CustomerOnlineID);
                                        CustomerDatabaseRef.setValue(true);
                                        Intent intent = new Intent(register_customer.this,CustomerMapActivity.class);
                                        startActivity(intent);
                                        finish();
                                        Toast.makeText(register_customer.this, "Customer Registered.",
                                                Toast.LENGTH_SHORT).show();
                                        loadingbar.dismiss();


                                    } else {
                                        Toast.makeText(register_customer.this, "Customer Registration Error." + task.getException().toString(),
                                                Toast.LENGTH_SHORT).show();
                                        loadingbar.dismiss();
                                    }
                                }
                            });
                }
            }
        });
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(register_customer.this,logincustomer.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
