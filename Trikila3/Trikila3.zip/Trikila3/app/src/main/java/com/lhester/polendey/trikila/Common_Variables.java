package com.lhester.polendey.trikila;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Common_Variables {
    public static DatabaseReference drivers_available = FirebaseDatabase.getInstance().getReference().child("Drivers Available");
    public static DatabaseReference drivers_working = FirebaseDatabase.getInstance().getReference().child("Drivers Working");
    public static DatabaseReference customer_requests = FirebaseDatabase.getInstance().getReference().child("Customer Requests");
    public static DatabaseReference users_customers = FirebaseDatabase.getInstance().getReference().child("Customers");
    public static DatabaseReference users_drivers = FirebaseDatabase.getInstance().getReference().child("Drivers");

    public static String customer_id= "";
    public static String drivers_id="";


}
